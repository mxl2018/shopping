<template>
  <div class="users">
    <!-- 面包屑导航 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item to="/users">用户管理</el-breadcrumb-item>
      <el-breadcrumb-item>用户列表</el-breadcrumb-item>
    </el-breadcrumb>
    <!-- 搜索框功能 -->
    <div>
      <el-input placeholder="请输入关键字" v-model="query" class="input-with-select">
        <el-button slot="append" icon="el-icon-search" @click="search"></el-button>
      </el-input>
      <el-button type="success" plain>用户添加</el-button>
    </div>
    <!-- 表格展示功能 -->
    <!-- el-table:表格组件 -->
    <!-- :data="tableData": 需要给表格组件传递数据 -->
    <!-- el-table-column：表格的一列 -->
    <!-- label：表格这一列的标题 -->
    <!-- prop： 这一列对应的数据的属性名 -->
    <el-table
      :data="userList"
      style="width: 100%">
      <el-table-column
        prop="username"
        label="姓名"
        width="180">
      </el-table-column>
      <el-table-column
        prop="email"
        label="邮箱"
        width="180">
      </el-table-column>
      <el-table-column
        prop="mobile"
        label="电话"
        width="180">
      </el-table-column>
      <el-table-column
        label="状态"
        width="180">
        <template slot-scope="scope">
          <el-switch
            v-model="scope.row.mg_state"
            active-color="#13ce66"
            inactive-color="#ff4949">
          </el-switch>
        </template>
      </el-table-column>
      <el-table-column
        label="操作">
        <!-- 自定义这一列的内容，必须指定template -->
        <template slot-scope="scope">
          <el-button size="small" plain type="primary" icon="el-icon-edit"></el-button>
          <el-button size="small" plain type="danger" icon="el-icon-delete" @click="delUser(scope.row.id)"></el-button>
          <el-button size="small" plain type="success" icon="el-icon-check">分配角色</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页功能 -->
    <!-- current-change： 当页面发生改变的时候 -->
    <!-- size-change: 当每页的条数发生改变的时候 -->
    <!-- current-page:显示当前页 -->
    <!-- page-size:每页显示的条数 -->
    <!-- total:总条数 -->
    <!-- layout:控制分页的子组件的显示 -->
     <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="currentPage"
      :page-size="pageSize"
      :total="total"
      :page-sizes="[2, 4, 6, 8]"
      background
      layout="total, sizes, prev, pager, next, jumper"
     >
    </el-pagination>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  data() {
    return {
      // 查询关键字
      query: '',
      // 当前页
      currentPage: 1,
      // 每页显示的条数
      pageSize: 2,
      // 总的条数
      total: 0,
      // 用户的列表数据
      userList: []
    }
  },
  methods: {
    // 获取用户列表信息
    getUserList() {
      // 发送ajax请求，获取用户列表数据
      axios({
        method: 'get',
        url: 'http://localhost:8888/api/private/v1/users',
        params: {
          query: this.query,
          pagenum: this.currentPage,
          pagesize: this.pageSize
        },
        headers: {
          Authorization: localStorage.getItem('token')
        }
      }).then(res => {
        console.log(res.data)
        if (res.data.meta.status === 200) {
          this.userList = res.data.data.users
          this.total = res.data.data.total
        }
      })
    },
    handleCurrentChange(val) {
      // val就是当前页
      // console.log(val)
      // 修改当前页
      this.currentPage = val
      // 重新发送ajax请求获取数据
      this.getUserList()
    },
    // 每页条数发生改变
    handleSizeChange(val) {
      console.log(val)
      // 改变每页条数的时候，需不需要把页码改成1
      this.currentPage = 1
      this.pageSize = val
      // 重新渲染
      this.getUserList()
    },
    // 搜索功能
    search() {
      // 搜索需要把当前改成1
      this.currentPage = 1
      this.getUserList()
    },
    // 删除用户
    delUser(id) {
      console.log(id)
      this.$confirm('你确定要删除这个用户吗？', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        axios({
          method: 'delete',
          url: `http://localhost:8888/api/private/v1/users/${id}`,
          headers: {
            Authorization: localStorage.getItem('token')
          }
        }).then(res => {
          if (res.data.meta.status === 200) {
            // 1. 重新渲染
            if(this.userList.length === 1 && this.currentPage > 1) {
              this.currentPage--
            }
            this.getUserList()
            // 2. 提示删除成功,  问题：如果当前页只有一条数据的时候，页码值-1
            this.$message.success('删除成功了')
          }
        })
      }).catch(() => {
        this.$message.error('你取消了删除操作')
      })
    }
  },
  created() {
    this.getUserList()
  }
}
</script>

<style lang="less" scoped>
.el-breadcrumb {
  height: 30px;
  line-height: 30px;
}

.el-input {
  width: 400px;
  margin-bottom: 10px;
}
</style>
